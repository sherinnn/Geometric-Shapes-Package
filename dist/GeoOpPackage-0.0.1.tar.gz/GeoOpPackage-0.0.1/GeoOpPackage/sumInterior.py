def sumInterior(n):
    if(n > 2):
        return ((n - 2) * 180)
    else:
        return 0
 
# # Driver code
# n = 5
# print(sumInterior(5))
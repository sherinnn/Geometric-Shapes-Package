import math

def circArea(r):
    if(r>0):
        return math.pi* pow(r,2)
    else:
        return 0
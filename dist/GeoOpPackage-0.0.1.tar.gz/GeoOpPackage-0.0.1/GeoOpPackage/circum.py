import math

def circum(r):
    if(r>0):
        math.pi*2*r
    else:
        return 0

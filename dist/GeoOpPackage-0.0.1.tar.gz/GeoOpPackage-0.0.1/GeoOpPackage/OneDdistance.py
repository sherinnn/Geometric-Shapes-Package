import math
 
def distance(x1 , x2):
    return math.fabs(x2 - x1)